# python-prms
python programmes for idea

python programmes to implement machine leanring algorithms using visual code and spyder,jupyter notebook

and best learning websites for various technologies listed in wiki pages
